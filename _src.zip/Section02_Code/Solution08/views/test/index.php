<?php

/* @var $this yii\web\View */

?>

<?= $this->render('//common/alert') ?>

<h2>Guest page</h2>
<p>There's a content of guest page</p>