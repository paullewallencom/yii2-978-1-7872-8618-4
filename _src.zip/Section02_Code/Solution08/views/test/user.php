<?php

/* @var $this yii\web\View */

?>

<?= $this->render('//common/alert') ?>

<h2>User page</h2>
<p>There's a content of user page</p>