<div class="quote">
    <h2>&ldquo;<?= $content?>&rdquo;, <?= $author?></h2>
</div>