<?php

return [
    'adminEmail' => 'admin@example.com',
    'key' => 'mysec123re123t1k23e123y123'
];
