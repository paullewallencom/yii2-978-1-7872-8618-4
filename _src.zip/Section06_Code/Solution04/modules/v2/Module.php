<?php
namespace app\modules\v2;

class Module extends  \yii\base\Module
{
    public function init()
    {
        parent::init();
    }
}