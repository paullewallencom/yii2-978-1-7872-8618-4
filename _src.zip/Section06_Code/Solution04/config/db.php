<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=yii-book',
    'username' => 'yii-book',
    'password' => 'yii-book777',
    'charset' => 'utf8',
];
