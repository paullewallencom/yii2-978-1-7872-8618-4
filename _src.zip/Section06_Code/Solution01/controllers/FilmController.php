<?php

namespace app\controllers;

use yii\rest\ActiveController;

class FilmController extends ActiveController
{
    public $modelClass = 'app\models\Film';
}
