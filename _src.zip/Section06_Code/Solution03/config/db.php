<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=104.236.50.77;dbname=yii-book',
    'username' => 'yii-book',
    'password' => 'yii-book777',
    'charset' => 'utf8',
];


