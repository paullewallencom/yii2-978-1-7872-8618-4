<?php

namespace awesome\namespaced;

class Library
{
    public function method()
    {
        return 'I am an awesome library with namespace.';
    }
}