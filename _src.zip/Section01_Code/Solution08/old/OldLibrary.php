<?php

class OldLibrary
{
    function method()
    {
        return 'I am an old library without namespace.';
    }
}