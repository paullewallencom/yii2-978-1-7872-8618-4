<?php

function simpleFunction()
{
    return 'I am a simple function.';
}