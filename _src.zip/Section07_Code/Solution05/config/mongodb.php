<?php

return [
    'class' => 'yii\mongodb\Connection',
    'dsn' => 'mongodb://localhost:27017/mydatabase',
];
