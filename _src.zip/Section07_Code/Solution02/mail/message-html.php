<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $name string */
?>

<p>Hello, <?= Html::encode($name) ?>!</p>