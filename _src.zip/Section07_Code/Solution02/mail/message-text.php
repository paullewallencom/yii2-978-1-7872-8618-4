<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $name string */
?>

Hello, <?= Html::encode($name) ?>!